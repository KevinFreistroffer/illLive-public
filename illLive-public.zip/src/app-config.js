//export const SERVER_URL = "http://localhost:1337/api";
export const SERVER_URL = "https://illlive.herokuapp.com/api";
