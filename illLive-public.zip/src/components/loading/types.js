export const SET_LOADER = "SET_LOADER";
