import React, { PropTypes } from 'react';

export const ShowSelectAMealMessage = (props) => {
	return (
	    <div className="select-a-meal-message flex center-all">
	      Please select a meal
	    </div>
	); 
};

export default ShowSelectAMealMessage;
