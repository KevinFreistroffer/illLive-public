import React, { Component } from "react";

export default class Account extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return <div>Account</div>;
  }
}
