export const DEFAULT_FOOD_OR_DRINK_VALUE = "Select a type";
export const DEFAULT_SELECTED_MEASUREMENT_VALUE = "Select a measurement";
