import * as vitaminsJSON from '../vitamins.json';

export const getVitamins = () => {
	return vitaminsJSON.vitamins;
}