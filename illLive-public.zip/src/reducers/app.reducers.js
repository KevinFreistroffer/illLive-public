export const initialState = {
	appName: 'illLive'
};

export const appReducers = (state = initialState, action) => {
	return state;
};