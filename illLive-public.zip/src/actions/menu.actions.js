import { TOGGLE_MENU } from "./types";

export const toggleMenu = () => {
	return {
		type: TOGGLE_MENU
	}
};